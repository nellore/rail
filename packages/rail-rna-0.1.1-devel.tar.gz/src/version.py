#!/usr/bin/env python
"""
version.py
Part of Rail-RNA

Stores version number of Rail-RNA as a string.
"""

version_number = '0.1.1-devel'